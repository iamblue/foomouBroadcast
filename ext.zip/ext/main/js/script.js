// When document is ready create click bindings.
$(document).ready( function() {
	var socket = io.connect('http://localhost:8880');
  var tmp = ''
  socket.on('news',function(d){
    
    if (tmp != d.main){
      webkitNotifications.checkPermission()
      var notification = webkitNotifications.createNotification(
        '48.png',  // icon url - can be relative
        d.location,  // notification title
        d.main  // notification body text
      );
      
      tmp = d.main
      $('.count').html(d.g0v)
      notification.show();  
    }
    
  })
});


